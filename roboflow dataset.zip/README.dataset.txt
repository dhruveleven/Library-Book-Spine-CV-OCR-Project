# Book spine instance segmentation > 2023-02-13 7:07am
https://universe.roboflow.com/harald-varner-xv5u7/book-spine-instance-segmentation

Provided by a Roboflow user
License: CC BY 4.0

